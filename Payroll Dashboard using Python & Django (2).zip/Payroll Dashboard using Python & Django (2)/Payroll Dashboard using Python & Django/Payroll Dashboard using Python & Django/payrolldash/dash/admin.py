from django.contrib import admin

from .models import basicpay
# admin.site.register(basicpay)
@admin.register(basicpay)
class basicpayadmin(admin.ModelAdmin):
    list_display=['empNo','basic_pay']

from .models import tax
# admin.site.register(tax)
@admin.register(tax)
class taxadmin(admin.ModelAdmin):
    list_display=['empNo','tax']
from django.contrib import admin

# Register your models here.
from .models import attendance
# admin.site.register(attendance)
@admin.register(attendance)
class attendanceadmin(admin.ModelAdmin):
    list_display=['empNo','month','presentday']
      