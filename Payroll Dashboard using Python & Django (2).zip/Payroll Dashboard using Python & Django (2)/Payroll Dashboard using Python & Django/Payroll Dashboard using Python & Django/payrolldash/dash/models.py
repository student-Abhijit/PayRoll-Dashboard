from django.db import models

# Create your models here.
class attendance(models.Model):
    empNo=models.IntegerField()
    month=models.CharField(max_length=20)
    presentday=models.CharField(max_length=100)
    
    

class basicpay(models.Model):
    empNo=models.IntegerField()
    basic_pay=models.IntegerField()
    
    
    
class tax(models.Model):
    empNo=models.IntegerField()
    tax=models.IntegerField()