from django.shortcuts import render,HttpResponse
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
# models
from .models import basicpay
from .models import attendance
from .models import tax

def home(request):
    data = attendance.objects.all()  #select * from attendance
    return render (request,"home.html",{'data':data})


def calculate_salary(request):
    if request.method=="POST":
        empNo= request.POST["empNo"]
        month= request.POST["month"]
        
        print(empNo,month)
        # Fetches the attendance record for the given empNo and month.
        # Extracts the number of present days (presentday) from the attendance record. 
        pday=attendance.objects.get(empNo=empNo,month=month)
        presentday=pday.presentday
        print("presentday::",presentday)
        
        gross=basicpay.objects.get(empNo=empNo)
        grosspay=gross.basic_pay
        print("basic_pay::",grosspay)
        
        # Fetches the tax record for the given empNo.
        # Extracts the tax amount (tax) from the record.
        taxdata=tax.objects.get(empNo=empNo)
        t=taxdata.tax
        print("tax::",t)
        
    #  leaves
        leaves= 30 - int(presentday)
        print("leaves::",leaves)
        
        # net pay
        netpay=grosspay - (leaves % t)
        print("netpay::",netpay)
              
        return JsonResponse({'gross_salary': grosspay, 'net_pay': netpay})

        return HttpResponse("Done")
    else:
        return HttpResponse("Fail")